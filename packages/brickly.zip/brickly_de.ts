<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en_US">
<context>
    <name>Logic</name>
    <message>
        <location filename="brickly_app.py" line="286"/>
        <source>true</source>
        <translation>wahr</translation>
    </message>
    <message>
        <location filename="brickly_app.py" line="287"/>
        <source>false</source>
        <translation>unwahr</translation>
    </message>
</context>
<context>
    <name>Menu</name>
    <message>
        <location filename="brickly_app.py" line="576"/>
        <source>Run...</source>
        <translation type="obsolete">Los...</translation>
    </message>
    <message>
        <location filename="brickly_app.py" line="953"/>
        <source>Stop!</source>
        <translation>Stopp!</translation>
    </message>
    <message>
        <location filename="brickly_app.py" line="937"/>
        <source>Run</source>
        <translation>Los</translation>
    </message>
    <message>
        <location filename="brickly_app.py" line="824"/>
        <source>Select...</source>
        <translation>Auswahl...</translation>
    </message>
</context>
<context>
    <name>Selection</name>
    <message>
        <location filename="brickly_app.py" line="735"/>
        <source>Program</source>
        <translation>Programm</translation>
    </message>
</context>
</TS>
