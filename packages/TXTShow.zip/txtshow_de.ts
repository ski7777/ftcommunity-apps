<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en_US">
<context>
    <name>context</name>
    <message>
        <location filename="txtshow.py" line="137"/>
        <source>Smile...</source>
        <translation>Lächeln...</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="137"/>
        <source>Snap</source>
        <translation>Foto!</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="391"/>
        <source>Delay</source>
        <translation type="unfinished">Verzög.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="391"/>
        <source>Set slide show delay:</source>
        <translation type="unfinished">Wähle Diaschau-Verzögerung:</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="391"/>
        <source>Set</source>
        <translation type="unfinished">Wähle</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="867"/>
        <source>Info</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="467"/>
        <source>is already empty.</source>
        <translation type="unfinished">ist bereits leer.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="870"/>
        <source>Okay</source>
        <translation type="unfinished">Okay</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="677"/>
        <source>Warning</source>
        <translation type="unfinished">Warnung</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="474"/>
        <source>Permanently delete image </source>
        <translation type="unfinished">Lösche endgültig das Bild</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="474"/>
        <source>from album</source>
        <translation type="unfinished">aus Album</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="688"/>
        <source>Yes</source>
        <translation type="unfinished">Ja</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="685"/>
        <source>Cancel</source>
        <translation type="unfinished">Abbruch</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="492"/>
        <source>is empty. Nothing to copy.</source>
        <translation type="unfinished">ist leer. Nichts zu kopieren.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="498"/>
        <source>Copy</source>
        <translation type="unfinished">Kopiere</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="528"/>
        <source>to album:</source>
        <translation type="unfinished">zu Album:</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="535"/>
        <source>Image</source>
        <translation type="unfinished">Bild</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="535"/>
        <source>already exists in album</source>
        <translation type="unfinished">existiert bereits im Album</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="514"/>
        <source>Unable to copy image</source>
        <translation type="unfinished">Fehler beim Kopieren von Bild</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="548"/>
        <source>to album</source>
        <translation type="unfinished">zu Album</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="522"/>
        <source>is empty. Nothing to move.</source>
        <translation type="unfinished">ist leer. Nichts zu verschieben.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="528"/>
        <source>Move</source>
        <translation type="unfinished">Verschiebe</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="548"/>
        <source>Unable to move image</source>
        <translation type="unfinished">Fehler beim Verschieben von Bild</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="556"/>
        <source>is empty. Nothing to rename.</source>
        <translation type="unfinished">ist leer. Nichts zum Umbenennen.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="703"/>
        <source>Rename</source>
        <translation type="unfinished">Umbenenn.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="703"/>
        <source>Please enter new name for</source>
        <translation type="unfinished">Neuen Namen eingeben für</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="634"/>
        <source>Select</source>
        <translation type="unfinished">Wähle</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="634"/>
        <source>Album to open:</source>
        <translation type="unfinished">Zu öffnendes Album:</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="634"/>
        <source>Open</source>
        <translation type="unfinished">Öffnen</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="650"/>
        <source>New</source>
        <translation type="unfinished">Neu</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="650"/>
        <source>Album to be created:</source>
        <translation type="unfinished">Name des zu erstellenden Albums:</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="650"/>
        <source>MyAlbum</source>
        <translation type="unfinished">MeinAlbum</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="650"/>
        <source>Create</source>
        <translation type="unfinished">Erstelle</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="656"/>
        <source>already exists! Could not create.</source>
        <translation type="unfinished">gibt es schon. Kann nichts neues erstellen.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="666"/>
        <source>could not be created.</source>
        <translation type="unfinished">kann nicht erstellt werden.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="682"/>
        <source>Really permanently delete the album</source>
        <translation type="unfinished">Wirklich das Album</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="682"/>
        <source>with</source>
        <translation type="unfinished">mit</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="682"/>
        <source>images?</source>
        <translation type="unfinished">Bildern dauerhaft löschen?</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="696"/>
        <source>is the last album and can not be deleted.</source>
        <translation type="unfinished">ist das letzte Album und kann nicht gelöscht werden.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="709"/>
        <source>already exists! Could not rename.</source>
        <translation type="unfinished">gibt es schon. Kann nichts umbenennen.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="719"/>
        <source>could not be renamed.</source>
        <translation type="unfinished">kann nicht umbenannt werden.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="734"/>
        <source>Album:</source>
        <translation type="unfinished">Album:</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="803"/>
        <source>Wizard</source>
        <translation type="unfinished">Magie</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="805"/>
        <source>Do you want to hide the current album</source>
        <translation type="unfinished">Soll das aktuelle Album</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="805"/>
        <source>or do you want to show already hidden albums?</source>
        <translation type="unfinished">versteckt werden oder soll ein verstecktes Album angezeigt werden?</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="810"/>
        <source>Hide</source>
        <translation type="unfinished">Verstecken</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="846"/>
        <source>Show</source>
        <translation type="unfinished">Zeigen</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="849"/>
        <source>Key?</source>
        <translation type="unfinished">Schlüssel?</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="815"/>
        <source>Confirm</source>
        <translation type="unfinished">Bestätige</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="827"/>
        <source>Error</source>
        <translation type="unfinished">Fehler</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="828"/>
        <source>Keys did not match! Try again.</source>
        <translation type="unfinished">Schlüssel stimmen nicht überein. Bitte nochmal versuchen.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="835"/>
        <source>is the last album and can not be hidden.</source>
        <translation type="unfinished">ist das letzte Album und kann nicht versteckt werden.</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="846"/>
        <source>Select album to unlock:</source>
        <translation type="unfinished">Wähle wieder anzuzeigendes Album:</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="862"/>
        <source>Key not matching.</source>
        <translation type="unfinished">Schlüssel passt nicht!</translation>
    </message>
    <message>
        <location filename="txtshow.py" line="868"/>
        <source>No hidden albums found.</source>
        <translation type="unfinished">Keine versteckten Alben gefunden.</translation>
    </message>
</context>
</TS>
